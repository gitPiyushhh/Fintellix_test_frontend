var rte = new Rte();
rte.init(document.getElementById('output'))
rte.getContent()