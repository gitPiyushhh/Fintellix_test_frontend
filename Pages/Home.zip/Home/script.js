function reverseIcon(id) {
    const elem = document.getElementById(id);
    elem.classList.add('reverse')
}

function reverseIconBack(id) {
    const elem = document.getElementById(id);
    elem.classList.remove('reverse')
}